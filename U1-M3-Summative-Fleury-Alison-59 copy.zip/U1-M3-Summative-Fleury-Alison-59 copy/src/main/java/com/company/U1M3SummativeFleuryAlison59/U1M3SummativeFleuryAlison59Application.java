package com.company.U1M3SummativeFleuryAlison59;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U1M3SummativeFleuryAlison59Application {

	public static void main(String[] args) {
		SpringApplication.run(U1M3SummativeFleuryAlison59Application.class, args);
	}

}
