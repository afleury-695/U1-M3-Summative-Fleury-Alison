package com.company.U1M3SummativeFleuryAlison59;

public class Magic8Answers {

    public String answer;
    //public String question;

    public Magic8Answers() {

    }

    Magic8Answers(String answer) {
        this.answer = answer;
        //this.question = question;

    }

    //getter and setter if needed
    public String getAnswer() { return answer; }

    public void setAnswer(String answer) { this.answer = answer; }

    //public String getQuestion() { return question; }

   // public void setQuestion(String question) { this.question = question; }

}
